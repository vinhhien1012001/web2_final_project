<?php
$server = "localhost";
$user = "root";
$password = "";
$db_name = "final_db";

$conn = mysqli_connect($server, $user, $password, $db_name);
?>